from flask import Flask, request, render_template, redirect, url_for, session, flash
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash
from apscheduler.schedulers.background import BackgroundScheduler
from flask_socketio import SocketIO
from cryptography.fernet import Fernet
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging

# ----------------------------------------------------------------------------
# Opsætning af logging
# ----------------------------------------------------------------------------
logging.basicConfig(
    filename='app.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# ----------------------------------------------------------------------------
# Flask og SocketIO opsætning
# ----------------------------------------------------------------------------
app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")
app.secret_key = "min_secret_key"

# ----------------------------------------------------------------------------
# Limiter opsætning
# ----------------------------------------------------------------------------
limiter = Limiter(key_func=get_remote_address)
limiter.init_app(app)

# ----------------------------------------------------------------------------
# Database og krypteringsnøgle opsætning
# ----------------------------------------------------------------------------
current_dir = os.path.dirname(os.path.abspath(__file__))
db_name = "local_database.db"
db_path = os.path.join(current_dir, db_name)
key_path = os.path.join(current_dir, "key.txt")


try:
    with open("key.txt", "rb") as key_file:
        key = key_file.read()
        print(f"Krypteringsnøglen er hentet fra: {key_path}")
except FileNotFoundError:
    print(f"Fejl: key.txt ikke fundet i {key_path}")
    raise

cipher = Fernet(key)

def encrypt(data):
    return cipher.encrypt(data.encode()).decode()

def decrypt(data):
    return cipher.decrypt(data.encode()).decode()

# ----------------------------------------------------------------------------
# Funktion til at initialisere databasen
# ----------------------------------------------------------------------------
def init_db():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL,
        medicine TEXT NOT NULL,
        comments TEXT,
        consent_given BOOLEAN DEFAULT 0,
        status TEXT DEFAULT 'Ikke taget'
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS lock_status (
    id INTEGER PRIMARY KEY,
    status TEXT NOT NULL
    )
    ''')

    cursor.execute("INSERT OR IGNORE INTO lock_status (id, status) VALUES (1, 'locked')")

    cursor.execute('''
    CREATE TRIGGER IF NOT EXISTS update_patient_sequence
    AFTER DELETE ON patients
    BEGIN
        UPDATE sqlite_sequence
        SET seq = (SELECT MAX(id) FROM patients)
        WHERE name = 'patients';
    END;
    ''')

    conn.commit()
    conn.close()

# ----------------------------------------------------------------------------
# Initialiser databasen
# ----------------------------------------------------------------------------
init_db()

# ----------------------------------------------------------------------------
# Scheduler opsætning og funktioner
# ----------------------------------------------------------------------------
def reset_patient_status():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE patients SET status = 'Ikke taget'")
    conn.commit()
    conn.close()

    socketio.emit('status_update', {'message': 'Status nulstillet til "Ikke taget".'})
    print("Status nulstillet kl. 06:00")


@app.route('/take_medicine/<int:patient_id>', methods=['POST'])
def take_medicine(patient_id):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE patients SET status = 'Taget' WHERE id = ?", (patient_id,))
    conn.commit()
    conn.close()

    socketio.emit('status_update', {'message': f'Patient med ID {patient_id} har taget medicinen.'})

    flash(f"Patient med ID {patient_id} har taget medicinen!", "success")
    return redirect(url_for('dashboard'))


@app.route('/api/update_status', methods=['POST'])
def update_status():
    data = request.json
    patient_id = data.get('patient_id')

    if not patient_id:
        return {"error": "Patient ID mangler"}, 400

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE patients SET status = 'Taget' WHERE id = ?", (patient_id,))
    conn.commit()
    conn.close()

    socketio.emit('status_update', {'message': f'Patient med ID {patient_id} har taget medicinen.'})
    print("Socket.IO event sendt: status_update")
    return {"message": "Status opdateret"}, 200

# ----------------------------------------------------------------------------
# Hjemmesidens navbar routes
# ----------------------------------------------------------------------------
@app.route('/')
def index():
    return render_template("index.html")

@app.route('/omos')
def om_os():
    return render_template("omos.html")

@app.route('/kontakt')
def kontakt():
    return render_template("kontakt.html")

# ----------------------------------------------------------------------------
# Login og registrering routes
# ----------------------------------------------------------------------------
@app.errorhandler(429)
def ratelimit_handler(e):
    client_ip = request.remote_addr
    logging.warning(f"Rate limit nået for IP: {client_ip}")
    flash("For mange loginforsøg. Prøv igen senere.", "danger-login")
    return render_template("login.html"), 429


@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5 per minute")
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            logging.info(f"Login succesfuldt for bruger: {email}")
            flash("Du er nu logget ind!", "success-login")
            return redirect(url_for('dashboard'))
        else:
            logging.warning(f"Login mislykkedes for bruger: {email} fra IP: {request.remote_addr}")
            flash("Forkert email eller kodeord.", "danger-login")
    
    return render_template("login.html")


@app.route('/register', methods=['GET', 'POST'])
def register():

    INVITATION_CODE = "1234"

    if request.method == 'POST':
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        invitation_code = request.form['invitation_code']

        if invitation_code != INVITATION_CODE:
            logging.warning(f"Registreringsforsøg med ugyldig invitationkode: {invitation_code}")
            flash("Ugyldig invitationkode.", "danger-register")
            return redirect(url_for('register'))
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
            conn.commit()
            logging.info(f"Ny bruger registreret: {email}")
            flash("Registrering fuldført! Du kan nu logge ind.", "success-register")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            logging.warning(f"Registrering fejlede: Email {email} er allerede registreret.")
            flash("Emailen er allerede registreret.", "danger-register")
        finally:
            conn.close()

    return render_template("register.html")

# ----------------------------------------------------------------------------
# Dashboard routes
# ----------------------------------------------------------------------------
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash("Log ind for at få adgang til dashboardet.", "danger")
        return redirect(url_for('login'))

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, age, medicine, comments, consent_given, status FROM patients")
    patients = cursor.fetchall()
    conn.close()

    decrypted_patients = []
    for patient in patients:
        decrypted_patients.append((
            patient[0],
            decrypt(patient[1]),
            patient[2],
            decrypt(patient[3]),
            decrypt(patient[4]),
            patient[5],
            patient[6]
        ))

    return render_template("dashboard.html", decrypted_patients=decrypted_patients)


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash("Du er nu logget ud!.", "success-logout")
    return redirect(url_for('index'))

# ----------------------------------------------------------------------------
# Låsekontrol og afhentning af data fra ESP
# ----------------------------------------------------------------------------
@app.route('/control-lock', methods=['POST'])
def control_lock():
    action = request.form.get('action')
    if action == 'open lock':
        new_status = 'open lock'
        flash("Låsen er blevet åbnet!", "success")
    elif action == 'lock':
        new_status = 'locked'
        flash("Låsen er blevet låst!", "success")
    else:
        flash("Ugyldig handling.", "danger")
        return redirect(url_for('dashboard'))
    
    print(f"Låsestatus opdateret til: {new_status}")
    logging.info(f"Låsestatus opdateret til: {new_status}")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("UPDATE lock_status SET status = ? WHERE id = 1", (new_status,))
    conn.commit()
    conn.close()

    return redirect(url_for('dashboard'))


@app.route('/get-data', methods=['GET'])
def get_data():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT status FROM lock_status WHERE id = 1")
    status = cursor.fetchone()[0]
    conn.close()

    print(f"ESP hentede låsestatus: {status}")
    logging.info(f"ESP hentede låsestatus: {status}")

    return {"status": status}, 200

# ----------------------------------------------------------------------------
# Tilføjelse, sletning og ændring af patienter
# ----------------------------------------------------------------------------
@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    if 'user_id' not in session:
        flash("Log ind for at få adgang til dashboardet.", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = encrypt(request.form['name'])
        age = request.form['age']
        medicine = encrypt(request.form['medicine'])
        comments = encrypt(request.form['comments'])
        consent = 'consent' in request.form

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO patients (name, age, medicine, comments, consent_given) 
        VALUES (?, ?, ?, ?, ?)
        ''', (name, age, medicine, comments, consent))
        conn.commit()
        conn.close()

        logging.info(f"Patient tilføjet: {name}, Alder: {age}, Medicin: {medicine}, Kommentar: {comments}.")
        flash("Patient tilføjet!", "success")
        return redirect(url_for('dashboard'))

    return render_template("add_patient.html")



@app.route('/delete_patient/<int:patient_id>')
def delete_patient(patient_id):
    if 'user_id' not in session:
        flash("Log ind for at få adgang til dashboardet.", "danger")
        return redirect(url_for('login'))

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM patients WHERE id = ?", (patient_id,))
    patient_name = cursor.fetchone()[0]

    cursor.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
    conn.commit()
    conn.close()

    logging.warning(f"Patient slettet: ID {patient_id}, Navn: {patient_name}")
    flash("Patient slettet!", "success")
    return redirect(url_for('dashboard'))


@app.route('/edit_patient/<int:patient_id>', methods=['GET', 'POST'])
def edit_patient(patient_id):
    if 'user_id' not in session:
        flash("Log ind for at få adgang til dashboardet.", "danger")
        return redirect(url_for('login'))

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        medicine = request.form['medicine']
        comments = request.form['comments']

        cursor.execute('''
        UPDATE patients 
        SET name = ?, age = ?, medicine = ?, comments = ? 
        WHERE id = ?
        ''', (name, age, medicine, comments, patient_id))
        conn.commit()
        logging.warning(f"Patient opdateret: ID {patient_id}, Navn: {name}, Alder: {age}, Medicin: {medicine}, Kommentar: {comments}")
        flash("Patient opdateret!", "success")
        conn.close()
        return redirect(url_for('dashboard'))

    cursor.execute("SELECT id, name, age, medicine, comments FROM patients WHERE id = ?", (patient_id,))
    patient = cursor.fetchone()
    conn.close()

    return render_template("edit_patient.html", patient=patient)

# ----------------------------------------------------------------------------
# Start scheduler
# ----------------------------------------------------------------------------
scheduler = BackgroundScheduler()
scheduler.add_job(func=reset_patient_status, trigger="cron", hour=6)
scheduler.start()

# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)