import os
import paramiko
import time

# ----------------------------------------------------------------------------
# Find sti til den aktuelle databasefil
# ----------------------------------------------------------------------------
current_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(current_dir, "local_database.db")

# ----------------------------------------------------------------------------
# Upload database til server via SCP
# ----------------------------------------------------------------------------
def upload_database_via_scp(db_path, scp_config):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            hostname=scp_config["host"],
            username=scp_config["user"],
            password=scp_config["passwd"],
            port=scp_config.get("port", 22)
        )

        sftp = ssh.open_sftp()
        remote_path = os.path.join(scp_config["remote_folder"], "local_database.db")
        sftp.put(db_path, remote_path)
        sftp.close()
        ssh.close()
        print(f"Database uploadet til: {remote_path}")
    except Exception as e:
        print(f"Fejl under SCP-upload: {e}")

# ----------------------------------------------------------------------------
# Konfiguration for SCP-forbindelse
# ----------------------------------------------------------------------------
scp_details = {
    "host": "192.168.1.102",
    "user": "oguz",
    "passwd": "4375",
    "remote_folder": "/home/oguz/Skrivebord/Backup/"
}

# ----------------------------------------------------------------------------
# Overvåg databaseændringer og udfør backup
# ----------------------------------------------------------------------------
def monitor_and_backup():
    print("Uploader initial backup...")
    upload_database_via_scp(db_path, scp_details)
    last_modified = os.path.getmtime(db_path)

    while True:
        time.sleep(1)
        current_modified = round(os.path.getmtime(db_path), 2)
        print(f"Seneste ændringstid: {last_modified}, Nuværende ændringstid: {current_modified}")

        if current_modified != last_modified:
            print("Ændringer fundet i databasen. Uploader...")
            upload_database_via_scp(db_path, scp_details)
            last_modified = current_modified
        else:
            time.sleep(5)

# ----------------------------------------------------------------------------
# Main 
# ----------------------------------------------------------------------------
if __name__ == "__main__":
    print("Starter database-overvågning og upload af backup...")
    monitor_and_backup()
