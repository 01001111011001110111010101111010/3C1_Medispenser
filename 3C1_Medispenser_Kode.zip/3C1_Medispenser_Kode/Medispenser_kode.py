import machine
from machine import Pin, PWM, ADC
from time import sleep, localtime, time
import neopixel
import network
import urequests
import _thread

# ----------------------------------------------------------------------------
# Wi-Fi konfiguration
# ----------------------------------------------------------------------------
SSID = "TP-Link_9D16"
PASSWORD = "85474024"

# ----------------------------------------------------------------------------
# Serverens URL'er
# ----------------------------------------------------------------------------
SERVER_URL = "http://192.168.1.101:5000/get-data"
UPDATE_URL = "http://192.168.1.101:5000/api/update_status"

# ----------------------------------------------------------------------------
# Initialisering
# ----------------------------------------------------------------------------
laser = Pin(27, Pin.OUT)
laser.value(1)

ldr = ADC(Pin(34))
ldr.atten(ADC.ATTN_11DB)

DISPENSER_PINS = [Pin(12, Pin.OUT), Pin(13, Pin.OUT), Pin(14, Pin.OUT), Pin(15, Pin.OUT)]
LOCK_PINS = [Pin(16, Pin.OUT), Pin(17, Pin.OUT), Pin(18, Pin.OUT), Pin(19, Pin.OUT)]

BUZZ_PIN = 26
buzzer = PWM(Pin(BUZZ_PIN, Pin.OUT))
buzzer.duty(0)

NEOPIXEL_PIN = 25
NUM_PIXELS = 12
np = neopixel.NeoPixel(Pin(NEOPIXEL_PIN), NUM_PIXELS)

step_sequence_forward = [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
]

step_sequence_backward = [
    [0, 0, 0, 1],
    [0, 0, 1, 0],
    [0, 1, 0, 0],
    [1, 0, 0, 0],
]

dispenser_active = False
previous_status = None

# ----------------------------------------------------------------------------
# Motorstyring
# ----------------------------------------------------------------------------
def step_motor(pins, steps, sequence):
    for _ in range(abs(steps)):
        for step in sequence:
            for i, pin in enumerate(pins):
                pin.value(step[i])
            sleep(0.01)

def step_forward_motor(pins, steps):
    print(f"Kører motor fremad med {steps} steps")
    step_motor(pins, steps, step_sequence_forward)

def step_backward_motor(pins, steps):
    print(f"Kører motor baglæns med {steps} steps")
    step_motor(pins, steps, step_sequence_backward)

# ----------------------------------------------------------------------------
# NeoPixel-funktioner
# ----------------------------------------------------------------------------
def update_neopixel(color):
    for i in range(NUM_PIXELS):
        np[i] = color
    np.write()

def neopixel_blink(color, times=2, duration=0.1, pause=0.1):
    for _ in range(times):
        update_neopixel(color)
        sleep(duration)
        update_neopixel((0, 0, 0))
        sleep(pause)

# ----------------------------------------------------------------------------
# Buzzer-funktioner
# ----------------------------------------------------------------------------
def buzzer_beep(times=2, duration=0.1, pause=0.1):
    for _ in range(times):
        buzzer.duty(512)
        sleep(duration)
        buzzer.duty(0)
        sleep(pause)

# ----------------------------------------------------------------------------
# Wi-Fi-forbindelse
# ----------------------------------------------------------------------------
def connect_wifi():
    print("Starter Wi-Fi-forbindelse...")
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)

    if not wlan.isconnected():
        print(f"Forbinder til Wi-Fi-netværket: {SSID}")
        wlan.connect(SSID, PASSWORD)
        timeout = 10
        while not wlan.isconnected() and timeout > 0:
            print(f"Venter på Wi-Fi... ({timeout} sekunder tilbage)")
            sleep(1)
            timeout -= 1

    if wlan.isconnected():
        print("Wi-Fi tilsluttet: ", wlan.ifconfig())
        return True
    else:
        print("Kunne ikke oprette forbindelse.")
        return False

# ----------------------------------------------------------------------------
# Serverovervågning
# ----------------------------------------------------------------------------
def monitor_server():
    global previous_status
    while True:
        try:
            response = urequests.get(SERVER_URL)
            if response.status_code == 200:
                data = response.json()
                status = data.get("status")
                print(f"Modtaget status fra serveren: {status}")

                if status != previous_status:
                    if status == "open lock":
                        print("Åbner låsen")
                        step_forward_motor(LOCK_PINS, 100)
                    elif status == "locked":
                        print("Låser låsen")
                        step_backward_motor(LOCK_PINS, 100)
                    previous_status = status
                else:
                    print("Status er uændret, ingen handling udført.")

                response.close()
            else:
                print(f"Fejl ved serverforespørgsel: HTTP {response.status_code}")
        except Exception as e:
            print(f"Fejl: {e}")

        sleep(5)

# ----------------------------------------------------------------------------
# Dispenser-planlægning
# ----------------------------------------------------------------------------
def schedule_dispenser():
    global dispenser_active
    while True:
        current_time = localtime()
        if current_time[3] == 7 and current_time[4] == 0:
            print("Kører dispenser motor 100 steps fremad")
            step_forward_motor(DISPENSER_PINS, 100)
            buzzer_beep()
            neopixel_blink((255, 0, 0))
            dispenser_active = True
            sleep(60)
        sleep(1)

# ----------------------------------------------------------------------------
# Medicinovervågning
# ----------------------------------------------------------------------------
def monitor_medicine():
    global dispenser_active
    while True:
        laser.value(1)
        ldr_value = ldr.read()      
        print(f"Overvåger LDR: {ldr_value}")

        if dispenser_active and ldr_value > 3000:
            print("Medicin taget. Stopper bippene og sender opdatering.")
            buzzer.duty(0)
            update_neopixel((0, 255, 0))
            sleep(1)
            update_neopixel((0, 0, 0))

            payload = {"patient_id": 1}
            try:
                response = urequests.post(UPDATE_URL, json=payload)
                print(f"Server svar: {response.status_code}")
                response.close()
            except Exception as e:
                print(f"Fejl ved opdatering: {e}")

            dispenser_active = False
            sleep(5)

        elif dispenser_active:
            buzzer_beep(1)
            neopixel_blink((255, 0, 0), times=1, duration=0.1, pause=0.4)
        else:
            update_neopixel((0, 0, 255))

        sleep(0.5)

# ---------------------------------------------------------------------------
# Hovedprogram
# ---------------------------------------------------------------------------
print("Medispenser starter...")

if connect_wifi():
    print("Forbinder til serveren og starter overvågning...")
    _thread.start_new_thread(monitor_server, ())
    _thread.start_new_thread(schedule_dispenser, ())
    monitor_medicine()
else:
    print("Fejl: Kunne ikke forbinde til Wi-Fi.")